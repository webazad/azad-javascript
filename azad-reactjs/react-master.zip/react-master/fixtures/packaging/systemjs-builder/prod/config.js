System.config({
  paths: {
    react: '../../../../build/dist/react.production.min.js',
    'react-dom': '../../../../build/dist/react-dom.production.min.js',
  },
});
