# Wordy
## Background

### Step 1

E.g.

> What is 5 plus 13?

The program should handle large numbers and negative numbers.

Use the tests to drive your solution by deleting the `skip` in one test at a time.

### Step 2

E.g.

> What is 5 plus 13?

> What is 7 minus 5?

> What is 6 multiplied by 4?

> What is 25 divided by 5?

### Step 3

E.g.

> What is 5 plus 13 plus 6?

> What is 7 minus 5 minus 1?

> What is 9 minus 3 plus 5?

> What is 3 plus 5 minus 8?

### Step 4

E.g.

> What is 5 plus 13?

> What is 7 minus 5?

> What is 6 times 4?

> What is 25 divided by 5?

> What is 78 plus 5 minus 3?

> What is 18 times 3 plus 16?

> What is 4 times 3 divided by 6?

> What is 4 plus 3 times 2?

### Extensions

Implement questions of the type:

> What is 2 raised to the 5th power?

Remember to write failing tests for this code.

## Tests

To run the specs follow these commands:

```shell
# to run in the command line run
learn

#to run in the browser
learn -b
```

*Note:* The math operations in the examples above should be performed in the order that they are written. However, in order to correctly follow order of operations, remember to add parentheses wherever needed. 
